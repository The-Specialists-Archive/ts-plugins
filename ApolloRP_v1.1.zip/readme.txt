Apollo RP v1.0 (http://ApolloRP.org)

For installation and configuration instructions, visit the wiki, at:
http://wiki.ApolloRP.org
