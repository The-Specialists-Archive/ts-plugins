If your Half-Life installation is not at C:\SIERRA\Half-Life\ ignore that path and replace it with the path of your Half-Life install.

Default paths:
C:\SIERRA\Half-Life\<mod> (for normal Half-Life) 
C:\Program Files\Steam\SteamApps\<username>\half-life\<mod> (for Steam Half-Life) 
C:\Program Files\Steam\SteamApps\<username>\dedicated server\<mod> (for dedicated Steam server) 
C:\HLServer\<mod> (for the dedicated server)


Metamod Installation:
Unzip the contents of the zip file to C:\SIERRA\Half-Life\mod. For example, to install to Counter-Strike, unzip to C:\SIERRA\Half-Life\cstrike\addons\RadioMod (unless your Half-Life is installed somewhere else). Then add the dll (RadioMod_MM.dll / RadioMod_i486.so) to metamod's plugins list and start the server. 

Add this for RadioMod (linux and windows):
addons\RadioMod\dlls\RadioMod_MM.dll

You do not need to configure DF_config.txt with metamod as it will not affect anything.

Non-Metamod Installation:
Unzip the contents of the zip file to C:\SIERRA\Half-Life\mod. For example, to install to Counter-Strike, unzip to C:\SIERRA\Half-Life\cstrike\addons\RadioMod (unless your Half-Life is installed somewhere else). If this is the first mod you're installing, open up the liblist.gam in your mod folder with notepad and edit the line that starts with gamedll (game_dll_linux when using linux) and change the text in the quotes to:

In Windows:
addons\RadioMod\dlls\RadioMod_MM.dll
In Linux:
addons/RadioMod/dlls/RadioMod_i486.so

Then open the file DF_config.txt or DF_configlinux.txt in the RadioMod folder. Make the contents of this file the name of the normal dll file the mod runs. Examples:

Counter-Strike -	Change to "mp.dll"
TFC -			Change to "tfc.dll"
Opposing Force -	Change to "opfor.dll"
Frontline -		Change to "frontline.dll"
Half-Life -		Change to "hl.dll"

If you're running linux, change it to the linux equivalent. You can also set the file to point to another mod.

NOTE FOR STEAM USERS: Make sure to make liblist.gam READ ONLY. To do this, right click the file and select properties. Check the Read Only box and click OK. If you don't do this, steam replaces the file with the original.

If you want to use DF_config.txt to point to another mod then set it to the name of that dll. Remember that the path is relative to the dlls folder so to back out of the dlls folder use ..\ as if .. was a name of a folder. For example, if you have another mod thats in addons\mymod\dlls\mymod.dll you can set DF_config.txt to ..\addons\mymod\dlls\mymod.dll and it will load that dll. You can only have one dll file in DF_config.txt. If you want to have more than one mod you'll have to make a chain of dlls which will always have to end with the mod dll. Example:

liblist.gam->mod1->mod2->Counter-Strike

DF_radio.txt configuration:
Each song is defined between sets of brackets { } and has key and value pairs in between.
You must at least define a file and a name for each song. The file must reside in sound\DF\radioloops\. The ShortName key can be used to give a song a name for the change_radio_song command. All other keys are described in the DF_radio.txt file.

Radio Mod Commands:
buildradio
 - Builds a radio.
useradio OR the use key
 - Shows the main radio menu.
change_radio_song [song]
 - Quickly changes the song on the radio without the menu. Replace [song] with one of the "ShortName"s in DF_radio.txt
radiostop
 - Quickly stops the song without the menu.
detradio
 - Quickly destroys the radio without the menu.

Radio Mod CVARS:
CVAR		Default
DF_radio_on	1
 - Controls whether or not players can build a radio.
DF_radio_dies	1
 - Controls whether or not the radio blows up from taking damage.


Need Help? Got questions or comments?
Post on the forums.
http://www.adminop.net/forums/